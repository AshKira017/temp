"""
Q2. LeNet-5 Model for Multiclass Image Classification using CIFAR10 Dataset
Source: https://www.cs.toronto.edu/~kriz/cifar.html
Loaded via: from tensorflow.keras.datasets import cifar10
Tasks: (a) Training loss/accuracy plots, (b) Confusion matrix,
       (c) Class-wise metrics, (d) Overall metrics
"""

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import (confusion_matrix, classification_report,
                             accuracy_score, precision_score, recall_score, f1_score)
import tensorflow as tf
from tensorflow.keras import layers, models
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.datasets import cifar10
from tensorflow.keras.preprocessing.image import ImageDataGenerator
import pandas as pd

# ──────────────────────────────────────────────
# 1. CONFIGURATION
# ──────────────────────────────────────────────
IMG_SIZE    = 32          # CIFAR-10: 32×32 RGB
NUM_CLASSES = 10
BATCH_SIZE  = 64
EPOCHS      = 10
CLASS_NAMES = ['Airplane', 'Automobile', 'Bird', 'Cat', 'Deer',
               'Dog', 'Frog', 'Horse', 'Ship', 'Truck']

# ──────────────────────────────────────────────
# 2. LOAD & PREPROCESS CIFAR-10
# ──────────────────────────────────────────────

def load_cifar10():
    (X_train, y_train_raw), (X_test, y_test_raw) = cifar10.load_data()

    # Normalize pixel values to [0, 1]
    X_train = X_train.astype(np.float32) / 255.0
    X_test  = X_test.astype(np.float32)  / 255.0

    y_train_raw = y_train_raw.flatten()
    y_test_raw  = y_test_raw.flatten()

    y_train_cat = to_categorical(y_train_raw, NUM_CLASSES)
    y_test_cat  = to_categorical(y_test_raw,  NUM_CLASSES)

    print(f"Train: {X_train.shape}, Test: {X_test.shape}")
    return X_train, y_train_cat, X_test, y_test_cat, y_test_raw

# ──────────────────────────────────────────────
# 3. LeNet-5 ARCHITECTURE (adapted for 32×32 RGB)
# ──────────────────────────────────────────────

def build_lenet5(input_shape=(IMG_SIZE, IMG_SIZE, 3), num_classes=NUM_CLASSES):
    model = models.Sequential([
        # C1: First conv + pooling
        layers.Conv2D(6, kernel_size=5, activation='tanh', padding='same',
                      input_shape=input_shape),
        layers.AveragePooling2D(pool_size=2, strides=2),

        # C3: Second conv + pooling
        layers.Conv2D(16, kernel_size=5, activation='tanh', padding='valid'),
        layers.AveragePooling2D(pool_size=2, strides=2),

        # C5: Fully-connected conv
        layers.Conv2D(120, kernel_size=5, activation='tanh', padding='valid'),

        # Flatten → Fully-connected layers
        layers.Flatten(),
        layers.Dense(84, activation='tanh'),
        layers.Dropout(0.5),
        layers.Dense(num_classes, activation='softmax')
    ], name='LeNet5_CIFAR10')

    model.compile(optimizer='adam',
                  loss='categorical_crossentropy',
                  metrics=['accuracy'])
    model.summary()
    return model

# ──────────────────────────────────────────────
# 4. (a) TRAIN & PLOT LOSS / ACCURACY
# ──────────────────────────────────────────────

def train_and_plot(model, X_train, y_train, X_test, y_test_cat):
    datagen = ImageDataGenerator(
        rotation_range=15,
        width_shift_range=0.1,
        height_shift_range=0.1,
        horizontal_flip=True,
        zoom_range=0.1
    )

    history = model.fit(
        datagen.flow(X_train, y_train, batch_size=BATCH_SIZE),
        validation_data=(X_test, y_test_cat),
        epochs=EPOCHS,
        steps_per_epoch=len(X_train) // BATCH_SIZE,
        verbose=1
    )

    epochs_range = range(1, EPOCHS + 1)
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))

    # Loss plot
    axes[0].plot(epochs_range, history.history['loss'],     'b-o', label='Train Loss')
    axes[0].plot(epochs_range, history.history['val_loss'], 'r-o', label='Val Loss')
    axes[0].set_title('Training & Validation Loss')
    axes[0].set_xlabel('Epoch'); axes[0].set_ylabel('Loss')
    axes[0].legend(); axes[0].grid(True)

    # Accuracy plot
    axes[1].plot(epochs_range, history.history['accuracy'],     'b-o', label='Train Accuracy')
    axes[1].plot(epochs_range, history.history['val_accuracy'], 'r-o', label='Val Accuracy')
    axes[1].set_title('Training & Validation Accuracy')
    axes[1].set_xlabel('Epoch'); axes[1].set_ylabel('Accuracy')
    axes[1].legend(); axes[1].grid(True)

    plt.suptitle('LeNet-5 on CIFAR-10 — Training Curves', fontsize=14, fontweight='bold')
    plt.tight_layout()
    plt.savefig('Q2_training_curves.png', dpi=150)
    plt.show()
    print("Saved: Q2_training_curves.png")
    return history

# ──────────────────────────────────────────────
# 5. (b) CONFUSION MATRIX
# ──────────────────────────────────────────────

def plot_confusion_matrix(y_true, y_pred):
    cm = confusion_matrix(y_true, y_pred)
    plt.figure(figsize=(10, 8))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
                xticklabels=CLASS_NAMES,
                yticklabels=CLASS_NAMES)
    plt.title('Confusion Matrix — LeNet-5 on CIFAR-10', fontsize=13, fontweight='bold')
    plt.ylabel('True Label'); plt.xlabel('Predicted Label')
    plt.xticks(rotation=30, ha='right')
    plt.tight_layout()
    plt.savefig('Q2_confusion_matrix.png', dpi=150)
    plt.show()
    print("Saved: Q2_confusion_matrix.png")

# ──────────────────────────────────────────────
# 6. (c) CLASS-WISE PERFORMANCE METRICS
# ──────────────────────────────────────────────

def class_wise_metrics(y_true, y_pred):
    report = classification_report(y_true, y_pred,
                                   target_names=CLASS_NAMES,
                                   output_dict=True)
    df_report = pd.DataFrame(report).transpose()
    print("\n──── (c) Class-wise Performance Metrics ────")
    print(df_report.round(4).to_string())

    # Visual bar chart
    metrics_df = df_report.iloc[:NUM_CLASSES][['precision', 'recall', 'f1-score']]
    metrics_df.plot(kind='bar', figsize=(13, 5), colormap='Set2', edgecolor='black')
    plt.title('Class-wise Precision / Recall / F1-Score', fontsize=13, fontweight='bold')
    plt.xlabel('CIFAR-10 Class'); plt.ylabel('Score')
    plt.xticks(rotation=30, ha='right'); plt.ylim(0, 1); plt.legend(loc='lower right')
    plt.tight_layout()
    plt.savefig('Q2_classwise_metrics.png', dpi=150)
    plt.show()
    print("Saved: Q2_classwise_metrics.png")
    return df_report

# ──────────────────────────────────────────────
# 7. (d) OVERALL PERFORMANCE METRICS
# ──────────────────────────────────────────────

def overall_metrics(y_true, y_pred):
    acc       = accuracy_score(y_true, y_pred)
    precision = precision_score(y_true, y_pred, average='weighted', zero_division=0)
    recall    = recall_score(y_true, y_pred, average='weighted', zero_division=0)
    f1        = f1_score(y_true, y_pred, average='weighted', zero_division=0)

    print("\n──── (d) Overall Performance Metrics ────")
    print(f"  Accuracy          : {acc:.4f}")
    print(f"  Weighted Precision: {precision:.4f}")
    print(f"  Weighted Recall   : {recall:.4f}")
    print(f"  Weighted F1-Score : {f1:.4f}")

    # Bar chart
    metrics = {'Accuracy': acc, 'Precision': precision, 'Recall': recall, 'F1-Score': f1}
    plt.figure(figsize=(7, 4))
    bars = plt.bar(metrics.keys(), metrics.values(),
                   color=['steelblue', 'darkorange', 'green', 'crimson'], edgecolor='black')
    for bar, val in zip(bars, metrics.values()):
        plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.01,
                 f'{val:.4f}', ha='center', va='bottom', fontsize=11, fontweight='bold')
    plt.ylim(0, 1.1)
    plt.title('Overall Performance Metrics — LeNet-5 CIFAR-10', fontsize=13, fontweight='bold')
    plt.ylabel('Score'); plt.tight_layout()
    plt.savefig('Q2_overall_metrics.png', dpi=150)
    plt.show()
    print("Saved: Q2_overall_metrics.png")

# ──────────────────────────────────────────────
# 8. MAIN
# ──────────────────────────────────────────────

if __name__ == '__main__':
    # Load CIFAR-10 (auto-downloads on first run via Keras)
    X_train, y_train_cat, X_test, y_test_cat, y_test_raw = load_cifar10()

    # Build model
    model = build_lenet5()

    # (a) Train and plot curves
    history = train_and_plot(model, X_train, y_train_cat, X_test, y_test_cat)

    # Predict
    y_pred_prob = model.predict(X_test)
    y_pred      = np.argmax(y_pred_prob, axis=1)

    # (b) Confusion matrix
    plot_confusion_matrix(y_test_raw, y_pred)

    # (c) Class-wise metrics
    class_wise_metrics(y_test_raw, y_pred)

    # (d) Overall metrics
    overall_metrics(y_test_raw, y_pred)

    # Save model
    model.save('Q2_lenet5_cifar10.h5')
    print("\nModel saved to Q2_lenet5_cifar10.h5")
