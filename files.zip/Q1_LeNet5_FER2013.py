"""
Q1. LeNet-5 Model for Facial Emotion Recognition using FER2013 Dataset
Categories: 0=Angry, 1=Disgust, 2=Fear, 3=Happy, 4=Sad, 5=Surprise, 6=Neutral
Tasks: (a) Training loss/accuracy plots, (b) Confusion matrix,
       (c) Class-wise metrics, (d) Overall metrics
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import (confusion_matrix, classification_report,
                             accuracy_score, precision_score, recall_score, f1_score)
import tensorflow as tf
from tensorflow.keras import layers, models
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.preprocessing.image import ImageDataGenerator
import os

# ──────────────────────────────────────────────
# 1. CONFIGURATION
# ──────────────────────────────────────────────
IMG_SIZE    = 48          # FER2013 images are 48×48 grayscale
NUM_CLASSES = 7
BATCH_SIZE  = 64
EPOCHS      = 10
EMOTION_LABELS = ['Angry', 'Disgust', 'Fear', 'Happy', 'Sad', 'Surprise', 'Neutral']

# ──────────────────────────────────────────────
# 2. LOAD FER2013 DATASET
#    Download from Kaggle:
#    https://www.kaggle.com/datasets/nicolejyt/facialexpressionrecognition
#    Place fer2013.csv in the working directory.
# ──────────────────────────────────────────────

def load_fer2013(csv_path='fer2013.csv'):
    """Parse FER2013 CSV into numpy arrays."""
    df = pd.read_csv(csv_path)

    def parse_pixels(pixel_string):
        return np.array(pixel_string.split(), dtype=np.float32).reshape(IMG_SIZE, IMG_SIZE, 1) / 255.0

    X = np.stack(df['pixels'].apply(parse_pixels).values)
    y = df['emotion'].values

    train_mask = df['Usage'] == 'Training'
    test_mask  = df['Usage'].isin(['PublicTest', 'PrivateTest'])

    X_train, y_train = X[train_mask], y[train_mask]
    X_test,  y_test  = X[test_mask],  y[test_mask]

    y_train_cat = to_categorical(y_train, NUM_CLASSES)
    y_test_cat  = to_categorical(y_test,  NUM_CLASSES)

    print(f"Train: {X_train.shape}, Test: {X_test.shape}")
    return X_train, y_train_cat, X_test, y_test_cat, y_test

# ──────────────────────────────────────────────
# 3. LeNet-5 ARCHITECTURE (adapted for 48×48 grayscale)
# ──────────────────────────────────────────────

def build_lenet5(input_shape=(IMG_SIZE, IMG_SIZE, 1), num_classes=NUM_CLASSES):
    model = models.Sequential([
        # C1: Conv layer
        layers.Conv2D(6, kernel_size=5, activation='tanh', padding='same',
                      input_shape=input_shape),
        layers.AveragePooling2D(pool_size=2, strides=2),

        # C3: Conv layer
        layers.Conv2D(16, kernel_size=5, activation='tanh', padding='valid'),
        layers.AveragePooling2D(pool_size=2, strides=2),

        # C5: Conv layer (fully-connected conv)
        layers.Conv2D(120, kernel_size=5, activation='tanh', padding='valid'),

        # Flatten → FC layers
        layers.Flatten(),
        layers.Dense(84, activation='tanh'),
        layers.Dropout(0.5),
        layers.Dense(num_classes, activation='softmax')
    ], name='LeNet5_FER2013')

    model.compile(optimizer='adam',
                  loss='categorical_crossentropy',
                  metrics=['accuracy'])
    model.summary()
    return model

# ──────────────────────────────────────────────
# 4. (a) TRAIN & PLOT LOSS / ACCURACY
# ──────────────────────────────────────────────

def train_and_plot(model, X_train, y_train, X_test, y_test_cat):
    datagen = ImageDataGenerator(
        rotation_range=10,
        width_shift_range=0.1,
        height_shift_range=0.1,
        horizontal_flip=True
    )

    history = model.fit(
        datagen.flow(X_train, y_train, batch_size=BATCH_SIZE),
        validation_data=(X_test, y_test_cat),
        epochs=EPOCHS,
        steps_per_epoch=len(X_train) // BATCH_SIZE,
        verbose=1
    )

    epochs_range = range(1, EPOCHS + 1)
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))

    # Loss plot
    axes[0].plot(epochs_range, history.history['loss'],     'b-o', label='Train Loss')
    axes[0].plot(epochs_range, history.history['val_loss'], 'r-o', label='Val Loss')
    axes[0].set_title('Training & Validation Loss')
    axes[0].set_xlabel('Epoch'); axes[0].set_ylabel('Loss')
    axes[0].legend(); axes[0].grid(True)

    # Accuracy plot
    axes[1].plot(epochs_range, history.history['accuracy'],     'b-o', label='Train Accuracy')
    axes[1].plot(epochs_range, history.history['val_accuracy'], 'r-o', label='Val Accuracy')
    axes[1].set_title('Training & Validation Accuracy')
    axes[1].set_xlabel('Epoch'); axes[1].set_ylabel('Accuracy')
    axes[1].legend(); axes[1].grid(True)

    plt.suptitle('LeNet-5 on FER2013 — Training Curves', fontsize=14, fontweight='bold')
    plt.tight_layout()
    plt.savefig('Q1_training_curves.png', dpi=150)
    plt.show()
    print("Saved: Q1_training_curves.png")
    return history

# ──────────────────────────────────────────────
# 5. (b) CONFUSION MATRIX
# ──────────────────────────────────────────────

def plot_confusion_matrix(y_true, y_pred):
    cm = confusion_matrix(y_true, y_pred)
    plt.figure(figsize=(9, 7))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
                xticklabels=EMOTION_LABELS,
                yticklabels=EMOTION_LABELS)
    plt.title('Confusion Matrix — LeNet-5 on FER2013', fontsize=13, fontweight='bold')
    plt.ylabel('True Label'); plt.xlabel('Predicted Label')
    plt.tight_layout()
    plt.savefig('Q1_confusion_matrix.png', dpi=150)
    plt.show()
    print("Saved: Q1_confusion_matrix.png")

# ──────────────────────────────────────────────
# 6. (c) CLASS-WISE PERFORMANCE METRICS
# ──────────────────────────────────────────────

def class_wise_metrics(y_true, y_pred):
    report = classification_report(y_true, y_pred,
                                   target_names=EMOTION_LABELS,
                                   output_dict=True)
    df_report = pd.DataFrame(report).transpose()
    print("\n──── (c) Class-wise Performance Metrics ────")
    print(df_report.round(4).to_string())

    # Visual bar chart
    metrics_df = df_report.iloc[:NUM_CLASSES][['precision', 'recall', 'f1-score']]
    metrics_df.plot(kind='bar', figsize=(12, 5), colormap='Set2', edgecolor='black')
    plt.title('Class-wise Precision / Recall / F1-Score', fontsize=13, fontweight='bold')
    plt.xlabel('Emotion Class'); plt.ylabel('Score')
    plt.xticks(rotation=30, ha='right'); plt.ylim(0, 1); plt.legend(loc='lower right')
    plt.tight_layout()
    plt.savefig('Q1_classwise_metrics.png', dpi=150)
    plt.show()
    print("Saved: Q1_classwise_metrics.png")
    return df_report

# ──────────────────────────────────────────────
# 7. (d) OVERALL PERFORMANCE METRICS
# ──────────────────────────────────────────────

def overall_metrics(y_true, y_pred):
    acc       = accuracy_score(y_true, y_pred)
    precision = precision_score(y_true, y_pred, average='weighted', zero_division=0)
    recall    = recall_score(y_true, y_pred, average='weighted', zero_division=0)
    f1        = f1_score(y_true, y_pred, average='weighted', zero_division=0)

    print("\n──── (d) Overall Performance Metrics ────")
    print(f"  Accuracy          : {acc:.4f}")
    print(f"  Weighted Precision: {precision:.4f}")
    print(f"  Weighted Recall   : {recall:.4f}")
    print(f"  Weighted F1-Score : {f1:.4f}")

    # Bar chart
    metrics = {'Accuracy': acc, 'Precision': precision, 'Recall': recall, 'F1-Score': f1}
    plt.figure(figsize=(7, 4))
    bars = plt.bar(metrics.keys(), metrics.values(),
                   color=['steelblue', 'darkorange', 'green', 'crimson'], edgecolor='black')
    for bar, val in zip(bars, metrics.values()):
        plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.01,
                 f'{val:.4f}', ha='center', va='bottom', fontsize=11, fontweight='bold')
    plt.ylim(0, 1.1)
    plt.title('Overall Performance Metrics — LeNet-5 FER2013', fontsize=13, fontweight='bold')
    plt.ylabel('Score'); plt.tight_layout()
    plt.savefig('Q1_overall_metrics.png', dpi=150)
    plt.show()
    print("Saved: Q1_overall_metrics.png")

# ──────────────────────────────────────────────
# 8. MAIN
# ──────────────────────────────────────────────

if __name__ == '__main__':
    # Load data (ensure fer2013.csv is in the current directory)
    X_train, y_train_cat, X_test, y_test_cat, y_test_raw = load_fer2013('fer2013.csv')

    # Build model
    model = build_lenet5()

    # (a) Train and plot curves
    history = train_and_plot(model, X_train, y_train_cat, X_test, y_test_cat)

    # Predict
    y_pred_prob = model.predict(X_test)
    y_pred      = np.argmax(y_pred_prob, axis=1)

    # (b) Confusion matrix
    plot_confusion_matrix(y_test_raw, y_pred)

    # (c) Class-wise metrics
    class_wise_metrics(y_test_raw, y_pred)

    # (d) Overall metrics
    overall_metrics(y_test_raw, y_pred)

    # Save model
    model.save('Q1_lenet5_fer2013.h5')
    print("\nModel saved to Q1_lenet5_fer2013.h5")
